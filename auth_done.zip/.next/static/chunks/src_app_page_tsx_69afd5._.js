(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_69afd5._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_69afd5._.js",
  "chunks": [
    "static/chunks/node_modules_framer-motion_dist_es_69e07e._.js",
    "static/chunks/node_modules_recharts_es6_util_44d8fd._.js",
    "static/chunks/node_modules_recharts_es6_component_d5776c._.js",
    "static/chunks/node_modules_recharts_es6_cartesian_114dc9._.js",
    "static/chunks/node_modules_recharts_es6_chart_3ece68._.js",
    "static/chunks/node_modules_recharts_es6_polar_024f0f._.js",
    "static/chunks/node_modules_recharts_es6_4eb7ca._.js",
    "static/chunks/node_modules_lodash_7678ac._.js",
    "static/chunks/node_modules_a8e629._.js",
    "static/chunks/src_e7e81e._.js"
  ],
  "source": "dynamic"
});
