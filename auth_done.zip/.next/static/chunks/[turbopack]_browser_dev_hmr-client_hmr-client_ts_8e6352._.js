(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_8e6352._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_8e6352._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_d6d8d4._.js"
  ],
  "source": "dynamic"
});
