export type TimelineItemType = {
    id: number;
    title: string;
    description: string;
    time: string;
  };